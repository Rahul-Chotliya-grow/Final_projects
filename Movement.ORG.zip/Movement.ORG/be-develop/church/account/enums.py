CATEGORY = (('unknown', 'unknown'), ("children", "children"), ("teeneger",
            "teeneger"), ("adult", "adult"))

ROLES = (('ADMIN', 'ADMIN'), ("USER", "USER"), )
