from django.contrib import admin
from .models import Giving

admin.site.register(Giving)
