from django.contrib import admin
from .models import SiteInfo

admin.site.register(SiteInfo)
